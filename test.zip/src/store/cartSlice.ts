import { createSlice } from '@reduxjs/toolkit';
import ProductItemDef from '../models/productItemDef';
import { cartItemDef } from '../models/cartItemsDef';

// ------------------------------------------------------------------------------------------
export interface cartPayload { payload: {item: ProductItemDef}}
export interface productId   { payload: {itemId: string}}

const items: Array<cartItemDef> = [];
const initCartState = {
  items: items,
  totCartQty: 0,
  totCartAmt: 0.0,
};


export const cartSlice = createSlice({
  name: 'cartSlice',
  initialState: initCartState,
  reducers: {
    addItem(state, action: cartPayload) {
      const newItem = action.payload.item;
      const tmpItem = state.items.find(item => item.product.productId === newItem.productId);

      if (tmpItem) {
        tmpItem.itemQty++;
        tmpItem.itemAmt  = tmpItem.itemQty * tmpItem.product.productPrice;
        state.totCartQty = state.totCartQty + 1;
        state.totCartAmt = state.totCartAmt + tmpItem.product.productPrice;
      }

      else {
        const newCartItem: cartItemDef = {
          product: newItem, 
          itemQty: 1,
          itemAmt: newItem.productPrice,
        };

        state.items.push(newCartItem);
        state.totCartQty = state.totCartQty + 1;
        state.totCartAmt = state.totCartAmt + newItem.productPrice;
      }
    },
    delItem(state, action: productId) {
      const tmpItem = state.items.find(item => item.product.productId === action.payload.itemId);
      if (tmpItem) {
        state.totCartQty--;
        
        if (tmpItem.itemQty <= 1) {
          state.items = state.items.filter(item => item.product.productId != tmpItem.product.productId);
        }
        else {
          tmpItem.itemQty--;
          tmpItem.itemAmt  = tmpItem.itemQty * tmpItem.product.productPrice;
        }
      }
    },

  }
});

export const cartActions    = cartSlice.actions;