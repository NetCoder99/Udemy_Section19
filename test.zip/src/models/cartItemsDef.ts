export {};

import ProductItemDef from './productItemDef';
export interface cartItemDef {
  product: ProductItemDef,
  itemQty: number,
  itemAmt: number,
};


// //import { useCounter } from "../hooks/useCounter";
// //const taskCounter = useCounter();

// import ProductItemDef from './productItemDef';
// class CartItemDef {

//   cartItemId: string;
//   cartProduct: ProductItemDef;
//   cartItemQty: number;
//   cartItemAmt: number;

//   constructor(cartItemId: string,  cartProduct: ProductItemDef);

//   constructor(cartItemId: string, cartProduct: ProductItemDef, cartItemDesc?: string, cartItemPrice?: number, cartItemQty?: number) {
//     this.cartItemId    = cartItemId;
//     this.cartProduct   = cartProduct;
//     this.cartItemQty   = cartItemQty   || 0;
//     this.cartItemAmt   = this.cartItemQty * this.cartProduct.productPrice;
//   }

// }

// //function getNextId(): string {
// //  taskCounter.increment();
// //  return "m" + taskCounter.counter.toString();
// //}

// export default CartItemDef;
