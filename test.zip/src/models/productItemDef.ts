//import { useCounter } from "../hooks/useCounter";
//const taskCounter = useCounter();

class ProductItemDef {
    productId: string;
    productName: string;
    productDesc: string;
    productPrice: number;
  
    constructor(productId: string);
    constructor(productId: string, productName?: string);
    constructor(productId: string, productName?: string, productDesc?: string, productPrice?: number) {
      this.productId    = productId;
      this.productName  = productName  || '';
      this.productDesc  = productDesc  || '';
      this.productPrice = productPrice || 0.0;
    }
  }
  
  //function getNextId(): string {
  //  taskCounter.increment();
  //  return "m" + taskCounter.counter.toString();
  //}
  
  export default ProductItemDef;
  