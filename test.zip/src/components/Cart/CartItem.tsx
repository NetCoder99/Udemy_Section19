import classes from './CartItem.module.css';

import { useDispatch } from "react-redux";
import { cartActions } from "../../store/cartSlice";
import { cartItemDef } from '../../models/cartItemsDef';
import ProductItemDef from '../../models/productItemDef';

const CartItem = (props: cartItemDef) => {
  const dispatch = useDispatch()

  const buttonHandlerAdd = (event: any) => {
    console.log("CartItem.buttonHandlerAdd:itemId:");
    const tempProd = new ProductItemDef("p99", "Temp");
    dispatch(cartActions.addItem({ item: props.product }));
  }

  const buttonHandlerDel = (event: any) => {
    console.log("CartItem.buttonHandlerDel:itemId:");
    dispatch(cartActions.delItem({ itemId: props.product.productId }));
  }

  return (
    <li className={`${classes.item} ${classes.row} `}>
      <div className={classes.column}>
        <h3>{props.product.productName}</h3>
      </div>
      <div className={classes.column}>
        <div className={classes.price}>
          ${props.itemAmt.toFixed(2)}{' '}
          <span className={classes.itemprice}>(${props.product.productPrice.toFixed(2)}/item) </span>
          x <span>{props.itemQty}</span>
        </div>
      </div>
      <div className={classes.columnLeft}>

        <div className={classes.details}>
          <div className={classes.actions}>
            <button onClick={buttonHandlerDel}>-</button>
            <button onClick={buttonHandlerAdd}>+</button>
          </div>
        </div>
      </div>
    </li>
  );
};

export default CartItem;
