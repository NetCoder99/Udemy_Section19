import Card from '../UI/Card';
import classes     from './Cart.module.css';
import CartItem    from './CartItem';

import { RootStateOrAny, useDispatch, useSelector  } from "react-redux";
import { cartActions }  from "../../store/cartSlice";
import { cartItemDef }  from '../../models/cartItemsDef';

import { uiActions  }   from "../../store/uiSlice";

const Cart = (props: any) => {
  const dispatch  = useDispatch()
  const cartSlice = useSelector((state: RootStateOrAny) => state.cartSlice);

  let headerMsg  = "Your Shopping Cart ";
  let content = "";

  if (cartSlice.items.length > 0) {
    const t1 = cartSlice.items[0].product;
    content = cartSlice.items.map(((item: JSX.IntrinsicAttributes & cartItemDef) => <CartItem {...item} />))
  }
  else {
    headerMsg = headerMsg + " is empty."
  };
  
  const buttonHandler = (event: any) => {
    console.log("CartButton.buttonHandler");
    dispatch(uiActions.hide());
  }

  return (
    <Card className={classes.cart}>
      <div> 
          <h2>{headerMsg}</h2>
         <button onClick={buttonHandler}>X</button>
      </div>
      <ul  className={classes.clear}>
        {content}
      </ul>
    </Card>
  );
};

export default Cart;
