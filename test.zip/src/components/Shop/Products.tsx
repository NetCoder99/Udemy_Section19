import ProductItem  from './ProductItem';
import classes      from './Products.module.css';
//import CartItemDef  from '../../models/cartItemsDef';
import productData  from '../../data/getProducts';

const Products = (props: any) => {

  const productList = productData.map((item => <ProductItem key={item.productId} {...item} />))

  return (
    <section className={classes.products}>
      <h2>Buy your favorite products</h2>
      <ul>
        {productList}
      </ul>
    </section>
  );
};

export default Products;
