import ProductItemDef from '../models/productItemDef';

const productData: ProductItemDef[] = [
    {
        productId: "p1",
        productName: "Toilet Paper",
        productDesc: "Softest Toilet Paper Ever",
        productPrice: 94.12
    },
    {
        productId: "p2",
        productName: "New TY",
        productDesc: "Brand New LCD TV",
        productPrice: 294.12
    },
    {
        productId: "p3",
        productName: "Desk - Wood",
        productDesc: "Premium Wooden Desk",
        productPrice: 541.22
    },
    {
        productId: "p4",
        productName: "Computer - Laptop",
        productDesc: "State of the art new Laptop",
        productPrice: 1025.81
    },

];

export default productData;
